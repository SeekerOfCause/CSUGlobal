#include <iostream>
#include <string>

int main()
{
    // Define variables for person's information
    std::string firstName = "John";
    std::string lastName = "Doe";
    std::string streetAddress = "123 Main St";
    std::string city = "Anytown";
    std::string zipCode = "12345";

    // Print the person's information
    std::cout << "First Name: " << firstName << std::endl;
    std::cout << "Last Name: " << lastName << std::endl;
    std::cout << "Street Address: " << streetAddress << std::endl;
    std::cout << "City: " << city << std::endl;
    std::cout << "Zip Code: " << zipCode << std::endl;

    return 0;
}
