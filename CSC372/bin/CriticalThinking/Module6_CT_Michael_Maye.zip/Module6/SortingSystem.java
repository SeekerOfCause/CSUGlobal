package CriticalThinking.Module6;

import java.util.ArrayList;
import java.util.Comparator;

public class SortingSystem {
	public static void main(String[] args) {
		ArrayList<Student> students = new ArrayList<>();

		students.add(new Student(1, "John", "123 Main St"));
		students.add(new Student(2, "Alice", "456 Elm St"));
		students.add(new Student(5, "David", "654 Cedar St"));
		students.add(new Student(3, "Bob", "789 Oak St"));
		students.add(new Student(7, "Michael", "234 Maple St"));
		students.add(new Student(4, "Sarah", "321 Pine St"));
		students.add(new Student(9, "Jacob", "890 Spruce St"));
		students.add(new Student(6, "Emily", "987 Walnut St"));
		students.add(new Student(8, "Olivia", "567 Birch St"));
		students.add(new Student(10, "Sophia", "432 Fir St"));

		System.out.println("Before sorting:");
		printStudents(students);

		// Sort by name using NameComparator
		SelectionSort.selectionSort(students, new NameComparator());
		System.out.println("\nAfter sorting by name:");
		printStudents(students);

		// Sort by roll number using RollNoComparator
		SelectionSort.selectionSort(students, new RollNoComparator());
		System.out.println("\nAfter sorting by roll number:");
		printStudents(students);
	}

	public static void printStudents(ArrayList<Student> students) {
		for (Student student : students) {
			System.out.println(student.toString());
		}
	}
}
