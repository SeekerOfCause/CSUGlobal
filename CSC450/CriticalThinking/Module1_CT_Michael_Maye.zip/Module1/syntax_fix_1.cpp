#include <iostream>
#include <conio.h>
// Standard namespace declaration
using namespace std;
// Main Function
int main()
{
    // Standard Ouput Statement
    cout << "Welcome to this C++ Program" << endl;
    cout << "I have corrected all errors for this program." << endl;
    // Wait For Output Screen
    // Main Function return Statement
    return 0;
}
